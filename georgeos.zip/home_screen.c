#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <ncurses.h>
#include <locale.h>
#include "home_screen.h"

char *apps[] = { 
    "Clock",
    "Disk Usage",
    "System Info",
    "Calculator",
    "System Monitor",
    "File Manager",
    "Weather",
    "Exit"
};

int num_apps = sizeof(apps) / sizeof(apps[0]);

void show_boot_screen(WINDOW *win) {
    werase(win);  // Clear the window
    box(win, 0, 0);  // Draw the box around the window

    // Display Tux ASCII Art step-by-step
    mvwprintw(win, 1, 2, "       .--.");
    mvwprintw(win, 2, 2, "      |o_o |");
    mvwprintw(win, 3, 2, "      |:_/ |");
    mvwprintw(win, 4, 2, "     //   \\ \\");
    mvwprintw(win, 5, 2, "    (|     | )");
    mvwprintw(win, 6, 2, "   /'\\_   _/`\\");
    mvwprintw(win, 7, 2, "   \\___)=(___/");
    wrefresh(win);  // Refresh the window to show Tux ASCII art
    sleep(1);  // Wait for 1 second before continuing

    // Boot messages with delays
    mvwprintw(win, 9, 4, "Booting GeorgeOS...");
    wrefresh(win);  // Refresh the window to show message
    sleep(2);  // Wait for 2 seconds

    mvwprintw(win, 10, 4, "Loading kernel modules...");
    wrefresh(win);
    sleep(2);

    mvwprintw(win, 11, 4, "Initializing system services...");
    wrefresh(win);
    sleep(2);

    mvwprintw(win, 12, 4, "Starting user interface...");
    wrefresh(win);
    sleep(2);

    wrefresh(win);  // Refresh to ensure all text is displayed
    sleep(1);  // Wait a moment before continuing

    werase(win);  // Clear the screen after boot
    box(win, 0, 0);
    mvwprintw(win, 1, 2, "Welcome to GeorgeOS!");
    wrefresh(win);
    sleep(1);  // Wait for 1 second before continuing
}

void show_clock(WINDOW *win) {
    time_t rawtime;
    struct tm *timeinfo;
    char buffer[80];
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, sizeof(buffer), "Current Time: %H:%M:%S", timeinfo);

    werase(win);
    box(win, 0, 0);
    mvwprintw(win, 1, 2, "GeorgeOS - Clock");
    mvwprintw(win, 3, 4, "%s", buffer);
    mvwprintw(win, 5, 4, "Press any key to return...");
    wrefresh(win);
    getch();
}

void show_disk_usage(WINDOW *win) {
    werase(win);
    box(win, 0, 0);
    mvwprintw(win, 1, 2, "GeorgeOS - Disk Usage");
    mvwprintw(win, 3, 4, "Fetching disk usage...");
    wrefresh(win);
    system("df -h > temp.txt");

    FILE *file = fopen("temp.txt", "r");
    char line[256];
    int y = 5;
    while (fgets(line, sizeof(line), file) && y < getmaxy(win) - 2) {
        mvwprintw(win, y++, 4, "%s", line);
    }
    fclose(file);
    mvwprintw(win, y + 1, 4, "Press any key to return...");
    wrefresh(win);
    getch();
}

void show_system_info(WINDOW *win) {
    werase(win);
    box(win, 0, 0);
    mvwprintw(win, 1, 2, "GeorgeOS - System Info");
    mvwprintw(win, 3, 4, "Fetching system info...");
    wrefresh(win);
    system("top -b -n 1 | head -n 10 > temp.txt");

    FILE *file = fopen("temp.txt", "r");
    char line[256];
    int y = 5;
    while (fgets(line, sizeof(line), file) && y < getmaxy(win) - 2) {
        mvwprintw(win, y++, 4, "%s", line);
    }
    fclose(file);
    mvwprintw(win, y + 1, 4, "Press any key to return...");
    wrefresh(win);
    getch();
}

void show_calculator(WINDOW *win) {
    double num1, num2, result;
    char op;
    werase(win);
    box(win, 0, 0);
    mvwprintw(win, 1, 2, "GeorgeOS - Calculator");
    mvwprintw(win, 3, 4, "Enter first number: ");
    wrefresh(win);
    scanw("%lf", &num1);
    mvwprintw(win, 4, 4, "Enter operator (+, -, *, /): ");
    wrefresh(win);
    scanw(" %c", &op);
    mvwprintw(win, 5, 4, "Enter second number: ");
    wrefresh(win);
    scanw("%lf", &num2);

    switch (op) {
        case '+': result = num1 + num2; break;
        case '-': result = num1 - num2; break;
        case '*': result = num1 * num2; break;
        case '/':
            if (num2 != 0) result = num1 / num2;
            else {
                mvwprintw(win, 6, 4, "Error: Division by zero");
                wrefresh(win);
                getch();
                return;
            }
            break;
        default:
            mvwprintw(win, 6, 4, "Invalid operator");
            wrefresh(win);
            getch();
            return;
    }

    mvwprintw(win, 6, 4, "Result: %.2lf", result);
    wrefresh(win);
    getch();
}

void show_system_monitor(WINDOW *win) {
    werase(win);
    box(win, 0, 0);
    mvwprintw(win, 1, 2, "GeorgeOS - System Monitor");
    mvwprintw(win, 3, 4, "Fetching system monitor data...");
    wrefresh(win);
    system("vmstat 1 5 > temp.txt");

    FILE *file = fopen("temp.txt", "r");
    char line[256];
    int y = 5;
    while (fgets(line, sizeof(line), file) && y < getmaxy(win) - 2) {
        mvwprintw(win, y++, 4, "%s", line);
    }
    fclose(file);
    mvwprintw(win, y + 1, 4, "Press any key to return...");
    wrefresh(win);
    getch();
}

void show_file_manager(WINDOW *win) {
    werase(win);
    box(win, 0, 0);
    mvwprintw(win, 1, 2, "GeorgeOS - File Manager");
    mvwprintw(win, 3, 4, "Listing files in current directory...");
    wrefresh(win);
    system("ls -lh > temp.txt");

    FILE *file = fopen("temp.txt", "r");
    char line[256];
    int y = 5;
    while (fgets(line, sizeof(line), file) && y < getmaxy(win) - 2) {
        mvwprintw(win, y++, 4, "%s", line);
    }
    fclose(file);
    mvwprintw(win, y + 1, 4, "Press any key to return...");
    wrefresh(win);
    getch();
}

void show_weather(WINDOW *win) {
    werase(win);
    box(win, 0, 0);
    mvwprintw(win, 1, 2, "GeorgeOS - Weather (Sarajevo)");
    mvwprintw(win, 3, 4, "Fetching weather...");
    wrefresh(win);
    system("curl -s wttr.in/Sarajevo?0 > temp.txt");

    FILE *file = fopen("temp.txt", "r");
    char line[256];
    int y = 5;
    while (fgets(line, sizeof(line), file) && y < getmaxy(win) - 2) {
        mvwprintw(win, y++, 4, "%s", line);
    }
    fclose(file);
    mvwprintw(win, y + 1, 4, "Press any key to return...");
    wrefresh(win);
    getch();
}

void show_home_screen(WINDOW *win) {
    int choice;
    int highlight = 0;

    show_boot_screen(win); // Show boot screen once at start

    keypad(win, TRUE);
    while (1) {
        werase(win);
        box(win, 0, 0);

        // Tux ASCII Art
        mvwprintw(win, 1, 2, "       .--.");
        mvwprintw(win, 2, 2, "      |o_o |");
        mvwprintw(win, 3, 2, "      |:_/ |");
        mvwprintw(win, 4, 2, "     //   \\ \\");
        mvwprintw(win, 5, 2, "    (|     | )");
        mvwprintw(win, 6, 2, "   /'\\_   _/`\\");
        mvwprintw(win, 7, 2, "   \\___)=(___/");
        mvwprintw(win, 9, 2, "copyright george 2025");

        for (int i = 0; i < num_apps; ++i) {
            if (i == highlight)
                wattron(win, A_REVERSE);
            mvwprintw(win, 11 + i, 4, "%s", apps[i]);
            wattroff(win, A_REVERSE);
        }

        wrefresh(win);
        choice = wgetch(win);

        switch (choice) {
            case KEY_UP:
                highlight = (highlight - 1 + num_apps) % num_apps;
                break;
            case KEY_DOWN:
                highlight = (highlight + 1) % num_apps;
                break;
            case 10:
                if (strcmp(apps[highlight], "Clock") == 0) show_clock(win);
                else if (strcmp(apps[highlight], "Disk Usage") == 0) show_disk_usage(win);
                else if (strcmp(apps[highlight], "System Info") == 0) show_system_info(win);
                else if (strcmp(apps[highlight], "Calculator") == 0) show_calculator(win);
                else if (strcmp(apps[highlight], "System Monitor") == 0) show_system_monitor(win);
                else if (strcmp(apps[highlight], "File Manager") == 0) show_file_manager(win);
                else if (strcmp(apps[highlight], "Weather") == 0) show_weather(win);
                else if (strcmp(apps[highlight], "Exit") == 0) return;
                break;
        }
    }
}
