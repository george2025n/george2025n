#ifndef HOME_SCREEN_H
#define HOME_SCREEN_H

#include <ncurses.h>

void show_home_screen(WINDOW *win);
void show_clock(WINDOW *win);
void show_disk_usage(WINDOW *win);
void show_system_info(WINDOW *win);
void show_calculator(WINDOW *win);
void show_system_monitor(WINDOW *win);
void show_file_manager(WINDOW *win);
void show_weather(WINDOW *win);
void show_terminal(WINDOW *win);

#endif
