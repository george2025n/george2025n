#include <ncurses.h>
#include <locale.h>
#include "home_screen.h"

int main() {
    // Set locale so ncurses supports Unicode
    setlocale(LC_ALL, "");

    // Initialize ncurses
    initscr();
    noecho();
    cbreak();
    curs_set(0);
    keypad(stdscr, TRUE);

    // Create main window
    WINDOW *mainwin = newwin(25, 80, 0, 0);
    refresh();

    // Show home screen
    show_home_screen(mainwin);

    // Clean up
    delwin(mainwin);
    endwin();
    return 0;
}
